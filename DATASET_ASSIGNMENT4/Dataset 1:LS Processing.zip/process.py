import os
import random

files = ['Class1.txt', 'Class2.txt', 'Class3.txt']

d = [open(i, 'r').read().splitlines() for i in files]
random.shuffle(d[0])
random.shuffle(d[1])
random.shuffle(d[2])

os.makedirs('test', exist_ok=True)
os.makedirs('train', exist_ok=True)
for i, file in enumerate(files):
    with open(f'train/{file}', 'w') as f:
        for line in d[i][:int(0.7*len(d[i]))]:
            f.write(f'{line}\n')
for i, file in enumerate(files):
    with open(f'test/{file}', 'w') as f:
        for line in d[i][int(0.7*len(d[i])):]:
            f.write(f'{line}\n')
